		<div class="entry-meta">
			<?php myf_posted_on(); ?>
		</div><!-- .entry-meta -->