	<footer class="entry-footer">
		<?php myf_entry_footer(); ?>
	</footer><!-- .entry-footer -->