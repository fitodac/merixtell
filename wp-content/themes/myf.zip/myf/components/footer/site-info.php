<div class="site-info">
	<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'myf' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'myf' ), 'WordPress' ); ?></a>
	<span class="sep"> | </span>
	<?php printf( esc_html__( 'Theme: %1$s by %2$s.', 'myf' ), 'MYF', '<a href="http://automattic.com/" rel="designer">Automattic</a>' ); ?>
</div><!-- .site-info -->